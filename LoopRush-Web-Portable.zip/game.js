const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
const scoreEl = document.getElementById("score");
const bestEl = document.getElementById("best");
const menu = document.getElementById("menu");
const gameOver = document.getElementById("gameOver");
const startBtn = document.getElementById("startBtn");
const againBtn = document.getElementById("againBtn");
const pauseBtn = document.getElementById("pauseBtn");
const pauseIcon = document.getElementById("pauseIcon");
const restartBtn = document.getElementById("restartBtn");
const restartIcon = document.getElementById("restartIcon");
const menuBtn = document.getElementById("menuBtn");
const menuIcon = document.getElementById("menuIcon");
const musicBtn = document.getElementById("musicBtn");
const musicIcon = document.getElementById("musicIcon");
const finalScore = document.getElementById("finalScore");
const resultLine = document.getElementById("resultLine");
const shareBtn = document.getElementById("shareBtn");
const themeButtons = document.querySelectorAll(".theme-btn");

const TAU = Math.PI * 2;
const THEMES = {
  neon: {
    player: "#f8fbff",
    ring: "rgba(248, 251, 255, 0.18)",
    spark: "#b8ff4b",
    shard: "#ff5670",
    cyan: "#35d7ff",
    bgA: "rgba(53, 215, 255, 0.22)",
    bgB: "rgba(255, 209, 102, 0.16)",
    bg1: "#111a27",
    bg2: "#161622",
    bg3: "#10151f",
    bass: [196, 196, 247, 196, 294, 247, 220, 247],
    lead: [392, 494, 587, 494, 659, 587, 494, 440, 392, 494, 587, 740, 659, 587, 494, 587]
  },
  sunset: {
    player: "#fffaf2",
    ring: "rgba(255, 250, 242, 0.2)",
    spark: "#ffd166",
    shard: "#7b5cff",
    cyan: "#ff8a4c",
    bgA: "rgba(255, 138, 76, 0.24)",
    bgB: "rgba(255, 209, 102, 0.2)",
    bg1: "#261621",
    bg2: "#211b2b",
    bg3: "#11151f",
    bass: [174, 220, 261, 220, 196, 247, 294, 247],
    lead: [349, 440, 523, 587, 523, 440, 392, 440, 523, 659, 587, 523, 440, 392, 349, 440]
  },
  mint: {
    player: "#f6fffb",
    ring: "rgba(246, 255, 251, 0.18)",
    spark: "#62f2b8",
    shard: "#ff5f7a",
    cyan: "#4bc3ff",
    bgA: "rgba(98, 242, 184, 0.2)",
    bgB: "rgba(75, 195, 255, 0.18)",
    bg1: "#10201e",
    bg2: "#122035",
    bg3: "#0d1418",
    bass: [165, 196, 247, 196, 220, 247, 294, 247],
    lead: [330, 392, 494, 587, 494, 392, 330, 392, 440, 554, 659, 554, 494, 440, 392, 330]
  },
  candy: {
    player: "#fff7ff",
    ring: "rgba(255, 247, 255, 0.18)",
    spark: "#ff5ad9",
    shard: "#35d7ff",
    cyan: "#8d6cff",
    bgA: "rgba(255, 90, 217, 0.2)",
    bgB: "rgba(141, 108, 255, 0.2)",
    bg1: "#20142b",
    bg2: "#1c2038",
    bg3: "#11151f",
    bass: [220, 277, 330, 277, 247, 311, 370, 311],
    lead: [440, 554, 659, 831, 740, 659, 554, 494, 554, 659, 740, 880, 831, 740, 659, 554]
  }
};

function loadBestScore() {
  try {
    return Number(localStorage.getItem("loopRushBest") || 0);
  } catch {
    return 0;
  }
}

function saveBestScore(value) {
  try {
    localStorage.setItem("loopRushBest", String(value));
  } catch {
    // Local file pages on some phones block storage. The game should still run.
  }
}

function loadThemeName() {
  try {
    const saved = localStorage.getItem("loopRushTheme");
    return THEMES[saved] ? saved : "neon";
  } catch {
    return "neon";
  }
}

function saveThemeName(name) {
  try {
    localStorage.setItem("loopRushTheme", name);
  } catch {}
}

let best = loadBestScore();
let themeName = loadThemeName();
let COLORS = THEMES[themeName];
let width = 0;
let height = 0;
let dpr = 1;
let state = "menu";
let lastTime = 0;
let score = 0;
let combo = 0;
let speed = 1.85;
let direction = 1;
let angle = -Math.PI / 2;
let spawnTimer = 0;
let pulse = 0;
let obstacles = [];
let particles = [];
let shake = 0;
let audioContext = null;
let musicEnabled = true;
let musicTimer = null;
let beat = 0;

bestEl.textContent = best;

function setTheme(name) {
  if (!THEMES[name]) return;
  themeName = name;
  COLORS = THEMES[themeName];
  saveThemeName(themeName);

  themeButtons.forEach((button) => {
    button.classList.toggle("is-active", button.dataset.theme === themeName);
  });

  if (state === "playing" && musicEnabled) {
    stopMusic();
    startMusic();
  }
}

function unlockAudio() {
  if (!audioContext) {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return null;
    audioContext = new AudioCtx();
  }
  if (audioContext.state === "suspended") {
    audioContext.resume();
  }
  return audioContext;
}

function playTone(frequency, duration, type = "sine", volume = 0.08) {
  const audio = unlockAudio();
  if (!audio) return;

  const oscillator = audio.createOscillator();
  const gain = audio.createGain();
  const now = audio.currentTime;

  oscillator.type = type;
  oscillator.frequency.setValueAtTime(frequency, now);
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(volume, now + 0.012);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

  oscillator.connect(gain);
  gain.connect(audio.destination);
  oscillator.start(now);
  oscillator.stop(now + duration + 0.02);
}

function playMusicNote(frequency, duration, type = "square", volume = 0.035, delay = 0) {
  const audio = unlockAudio();
  if (!audio || !musicEnabled) return;

  const oscillator = audio.createOscillator();
  const gain = audio.createGain();
  const filter = audio.createBiquadFilter();
  const now = audio.currentTime + delay;

  oscillator.type = type;
  oscillator.frequency.setValueAtTime(frequency, now);
  filter.type = "lowpass";
  filter.frequency.setValueAtTime(1100, now);
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(volume, now + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

  oscillator.connect(filter);
  filter.connect(gain);
  gain.connect(audio.destination);
  oscillator.start(now);
  oscillator.stop(now + duration + 0.03);
}

function musicTick() {
  if (!musicEnabled || state === "paused" || state === "over") return;

  const bass = COLORS.bass;
  const lead = COLORS.lead;
  const b = beat % 16;

  if (b % 2 === 0) {
    playMusicNote(bass[Math.floor(b / 2)], 0.12, "triangle", 0.045);
  }
  playMusicNote(lead[b], 0.08, "square", b % 4 === 0 ? 0.04 : 0.028, 0.02);
  if (b === 7 || b === 15) {
    playMusicNote(880, 0.045, "sine", 0.022, 0.06);
  }

  beat += 1;
}

function startMusic() {
  unlockAudio();
  if (musicTimer || !musicEnabled) return;
  beat = 0;
  musicTick();
  musicTimer = window.setInterval(musicTick, 165);
}

function stopMusic() {
  if (musicTimer) {
    window.clearInterval(musicTimer);
    musicTimer = null;
  }
}

function updateMusicButtons() {
  musicIcon.textContent = musicEnabled ? "M" : "X";
}

function toggleMusic() {
  musicEnabled = !musicEnabled;
  updateMusicButtons();
  if (musicEnabled && state === "playing") {
    startMusic();
  } else {
    stopMusic();
  }
}

function haptic(pattern) {
  if ("vibrate" in navigator) {
    navigator.vibrate(pattern);
  }
}

function shareScore() {
  const text = `I scored ${score} in Loop Rush. Can you beat me?`;
  if (navigator.share) {
    navigator.share({
      title: "Loop Rush",
      text
    }).catch(() => {});
    return;
  }

  if (navigator.clipboard) {
    navigator.clipboard.writeText(text).then(() => {
      resultLine.textContent = "Score copied. Send it to a friend.";
    }).catch(() => {
      resultLine.textContent = text;
    });
    return;
  }

  resultLine.textContent = text;
}

function resize() {
  dpr = Math.min(window.devicePixelRatio || 1, 2);
  width = window.innerWidth;
  height = window.innerHeight;
  canvas.width = Math.floor(width * dpr);
  canvas.height = Math.floor(height * dpr);
  canvas.style.width = `${width}px`;
  canvas.style.height = `${height}px`;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

function radius() {
  return Math.min(width, height) * 0.31;
}

function center() {
  return {
    x: width / 2,
    y: height * 0.53
  };
}

function resetGame() {
  score = 0;
  combo = 0;
  speed = 1.85;
  direction = 1;
  angle = -Math.PI / 2;
  spawnTimer = 0.65;
  pulse = 0;
  obstacles = [];
  particles = [];
  shake = 0;
  scoreEl.textContent = "0";
  pauseIcon.textContent = "II";
}

function startGame() {
  unlockAudio();
  resetGame();
  state = "playing";
  menu.classList.add("hidden");
  gameOver.classList.add("hidden");
  lastTime = performance.now();
  startMusic();
}

function returnToMenu() {
  if (state === "menu") return;
  state = "menu";
  pauseIcon.textContent = "II";
  menu.classList.remove("hidden");
  gameOver.classList.add("hidden");
  stopMusic();
}

function endGame() {
  state = "over";
  stopMusic();
  const oldBest = best;
  best = Math.max(best, score);
  saveBestScore(best);
  bestEl.textContent = best;
  finalScore.textContent = score;
  resultLine.textContent = score > oldBest ? "New best. One more run." : `Best: ${best}`;
  gameOver.classList.remove("hidden");
  playTone(140, 0.24, "sawtooth", 0.07);
  haptic([70, 40, 90]);
}

function togglePause() {
  if (state === "playing") {
    state = "paused";
    pauseIcon.textContent = ">";
    stopMusic();
  } else if (state === "paused") {
    state = "playing";
    pauseIcon.textContent = "II";
    lastTime = performance.now();
    startMusic();
  }
}

function reverse() {
  if (state === "menu") {
    startGame();
    return;
  }
  if (state !== "playing") return;
  direction *= -1;
  pulse = 1;
  burst(playerPosition(), COLORS.cyan, 8, 0.55);
  playTone(direction > 0 ? 380 : 300, 0.055, "triangle", 0.045);
  haptic(12);
}

function playerPosition() {
  const c = center();
  const r = radius();
  return {
    x: c.x + Math.cos(angle) * r,
    y: c.y + Math.sin(angle) * r
  };
}

function spawnObstacle() {
  const isSpark = Math.random() > Math.min(0.5, 0.18 + score / 360);
  const gap = Math.PI * (0.18 + Math.random() * 0.24);
  const away = direction > 0 ? angle + Math.PI + gap : angle - Math.PI - gap;

  obstacles.push({
    angle: away + (Math.random() - 0.5) * 0.75,
    drift: (Math.random() - 0.5) * 0.18,
    type: isSpark ? "spark" : "shard",
    size: isSpark ? 13 : 17,
    born: 0
  });
}

function burst(point, color, count, force) {
  for (let i = 0; i < count; i += 1) {
    const a = Math.random() * TAU;
    const v = force * (0.6 + Math.random() * 1.5);
    particles.push({
      x: point.x,
      y: point.y,
      vx: Math.cos(a) * v,
      vy: Math.sin(a) * v,
      life: 0.45 + Math.random() * 0.35,
      max: 0.8,
      color
    });
  }
}

function angleDistance(a, b) {
  return Math.atan2(Math.sin(a - b), Math.cos(a - b));
}

function collect(item) {
  const pos = pointOnRing(item.angle);
  if (item.type === "spark") {
    combo += 1;
    score += 1 + Math.floor(combo / 4);
    speed += 0.028;
    pulse = 1;
    burst(pos, COLORS.spark, 18, 1.15);
    scoreEl.textContent = score;
    playTone(520 + Math.min(combo, 12) * 26, 0.09, "sine", 0.07);
    haptic(18);
    return true;
  }

  shake = 1;
  burst(pos, COLORS.shard, 28, 1.5);
  endGame();
  return true;
}

function pointOnRing(a) {
  const c = center();
  const r = radius();
  return {
    x: c.x + Math.cos(a) * r,
    y: c.y + Math.sin(a) * r
  };
}

function update(dt) {
  if (state !== "playing") return;

  angle += direction * speed * dt;
  spawnTimer -= dt;
  pulse = Math.max(0, pulse - dt * 3.8);
  shake = Math.max(0, shake - dt * 3);

  if (spawnTimer <= 0) {
    spawnObstacle();
    spawnTimer = Math.max(0.36, 0.88 - score * 0.008 - Math.random() * 0.18);
  }

  obstacles = obstacles.filter((item) => {
    item.born += dt;
    item.angle += item.drift * dt;

    const diff = Math.abs(angleDistance(angle, item.angle));
    if (diff < 0.115) {
      return !collect(item);
    }

    if (item.born > 6.5) {
      if (item.type === "spark") combo = 0;
      return false;
    }

    return true;
  });

  particles = particles.filter((p) => {
    p.life -= dt;
    p.x += p.vx * 60 * dt;
    p.y += p.vy * 60 * dt;
    p.vx *= 0.985;
    p.vy *= 0.985;
    return p.life > 0;
  });
}

function drawBackground() {
  ctx.clearRect(0, 0, width, height);
  const bg = ctx.createLinearGradient(0, 0, width, height);
  bg.addColorStop(0, COLORS.bg1);
  bg.addColorStop(0.5, COLORS.bg2);
  bg.addColorStop(1, COLORS.bg3);
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, width, height);

  const glowA = ctx.createRadialGradient(width * 0.18, height * 0.2, 0, width * 0.18, height * 0.2, width * 0.45);
  glowA.addColorStop(0, COLORS.bgA);
  glowA.addColorStop(1, "rgba(0, 0, 0, 0)");
  ctx.fillStyle = glowA;
  ctx.fillRect(0, 0, width, height);

  const glowB = ctx.createRadialGradient(width * 0.82, height * 0.12, 0, width * 0.82, height * 0.12, width * 0.4);
  glowB.addColorStop(0, COLORS.bgB);
  glowB.addColorStop(1, "rgba(0, 0, 0, 0)");
  ctx.fillStyle = glowB;
  ctx.fillRect(0, 0, width, height);

  ctx.save();
  ctx.globalAlpha = 0.16;
  ctx.strokeStyle = "#f8fbff";
  ctx.lineWidth = 1;
  const spacing = 42;
  for (let x = -spacing; x < width + spacing; x += spacing) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x + height * 0.34, height);
    ctx.stroke();
  }
  ctx.restore();
}

function drawRing() {
  const c = center();
  const r = radius();
  const grow = pulse * 11;

  ctx.save();
  if (shake > 0) {
    ctx.translate((Math.random() - 0.5) * shake * 12, (Math.random() - 0.5) * shake * 12);
  }

  ctx.lineWidth = 12 + pulse * 4;
  ctx.strokeStyle = COLORS.ring;
  ctx.beginPath();
  ctx.arc(c.x, c.y, r + grow, 0, TAU);
  ctx.stroke();

  ctx.lineWidth = 3;
  ctx.strokeStyle = COLORS.cyan;
  ctx.globalAlpha = 0.34;
  ctx.beginPath();
  ctx.arc(c.x, c.y, r - 17, angle - 0.82, angle + 0.82);
  ctx.stroke();
  ctx.globalAlpha = 1;

  obstacles.forEach(drawObstacle);
  drawPlayer();
  ctx.restore();
}

function drawPlayer() {
  const p = playerPosition();

  ctx.save();
  ctx.shadowBlur = 26;
  ctx.shadowColor = COLORS.cyan;
  ctx.fillStyle = COLORS.player;
  ctx.beginPath();
  ctx.arc(p.x, p.y, 13 + pulse * 3, 0, TAU);
  ctx.fill();

  ctx.lineWidth = 4;
  ctx.strokeStyle = COLORS.cyan;
  ctx.beginPath();
  ctx.arc(p.x, p.y, 20 + pulse * 8, 0, TAU);
  ctx.stroke();
  ctx.restore();
}

function drawObstacle(item) {
  const p = pointOnRing(item.angle);

  ctx.save();
  ctx.translate(p.x, p.y);
  ctx.rotate(item.angle + Math.PI / 2);

  if (item.type === "spark") {
    ctx.shadowBlur = 18;
    ctx.shadowColor = "rgba(255, 206, 61, 0.55)";
    ctx.fillStyle = "#ffd440";
    ctx.beginPath();
    ctx.arc(0, 0, item.size, 0, TAU);
    ctx.fill();

    ctx.strokeStyle = "#e4b02a";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(0, 0, item.size - 3, 0, TAU);
    ctx.stroke();

    ctx.fillStyle = "#ffec8a";
    ctx.beginPath();
    ctx.ellipse(0, 0, item.size * 0.52, item.size * 0.2, 0, 0, TAU);
    ctx.fill();

    ctx.fillStyle = "rgba(255, 255, 255, 0.55)";
    for (let i = 0; i < 6; i += 1) {
      const a = i * (TAU / 6);
      const x = Math.cos(a) * (item.size * 0.72);
      const y = Math.sin(a) * (item.size * 0.72);
      ctx.beginPath();
      ctx.arc(x, y, item.size * 0.08, 0, TAU);
      ctx.fill();
    }
  } else {
    ctx.shadowBlur = 22;
    ctx.shadowColor = COLORS.shard;
    ctx.fillStyle = COLORS.shard;

    ctx.beginPath();
    ctx.moveTo(0, -item.size);
    ctx.quadraticCurveTo(item.size * 1.05, -item.size * 0.35, item.size * 0.45, item.size * 0.85);
    ctx.lineTo(-item.size * 0.45, item.size * 0.85);
    ctx.quadraticCurveTo(-item.size * 1.05, -item.size * 0.35, 0, -item.size);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "#fff";
    ctx.beginPath();
    ctx.arc(-item.size * 0.28, -item.size * 0.18, item.size * 0.18, 0, TAU);
    ctx.arc(item.size * 0.28, -item.size * 0.18, item.size * 0.18, 0, TAU);
    ctx.fill();

    ctx.fillStyle = "#111";
    ctx.beginPath();
    ctx.arc(-item.size * 0.28, -item.size * 0.18, item.size * 0.08, 0, TAU);
    ctx.arc(item.size * 0.28, -item.size * 0.18, item.size * 0.08, 0, TAU);
    ctx.fill();

    ctx.fillStyle = "#ff8a8a";
    ctx.beginPath();
    ctx.arc(0, item.size * 0.05, item.size * 0.16, 0, TAU);
    ctx.fill();

    ctx.fillStyle = COLORS.shard;
    ctx.beginPath();
    ctx.moveTo(-item.size * 0.55, -item.size * 0.65);
    ctx.lineTo(-item.size * 0.32, -item.size * 1.12);
    ctx.lineTo(-item.size * 0.12, -item.size * 0.62);
    ctx.closePath();
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(item.size * 0.55, -item.size * 0.65);
    ctx.lineTo(item.size * 0.32, -item.size * 1.12);
    ctx.lineTo(item.size * 0.12, -item.size * 0.62);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
}

function drawParticles() {
  particles.forEach((p) => {
    const alpha = Math.max(0, p.life / p.max);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, 3 + alpha * 4, 0, TAU);
    ctx.fill();
  });
  ctx.globalAlpha = 1;
}

function drawCenterText() {
  const c = center();
  ctx.save();
  ctx.textAlign = "center";
  ctx.fillStyle = "rgba(248, 251, 255, 0.9)";
  ctx.font = "900 18px system-ui, sans-serif";
  ctx.fillText(combo > 2 ? `${combo}x streak` : "tap to flip", c.x, c.y - 5);
  ctx.fillStyle = "rgba(174, 184, 200, 0.85)";
  ctx.font = "700 12px system-ui, sans-serif";
  ctx.fillText(`speed ${speed.toFixed(1)}`, c.x, c.y + 19);
  ctx.restore();
}

function draw() {
  drawBackground();
  drawRing();
  drawParticles();
  if (state === "playing" || state === "paused") drawCenterText();

  if (state === "paused") {
    ctx.fillStyle = "rgba(16, 21, 31, 0.48)";
    ctx.fillRect(0, 0, width, height);
    ctx.fillStyle = "#f8fbff";
    ctx.textAlign = "center";
    ctx.font = "900 34px system-ui, sans-serif";
    ctx.fillText("Paused", width / 2, height / 2);
  }
}

function loop(now) {
  const dt = Math.min(0.033, (now - lastTime) / 1000 || 0);
  lastTime = now;
  update(dt);
  draw();
  requestAnimationFrame(loop);
}

window.addEventListener("resize", resize);
window.addEventListener("pointerdown", (event) => {
  if (event.target.closest("button")) return;
  reverse();
});
window.addEventListener("keydown", (event) => {
  if (event.code === "Space" || event.code === "ArrowLeft" || event.code === "ArrowRight") {
    event.preventDefault();
    reverse();
  }
  if (event.code === "Escape") togglePause();
});

startBtn.addEventListener("click", startGame);
againBtn.addEventListener("click", startGame);
pauseBtn.addEventListener("click", togglePause);
restartBtn.addEventListener("click", startGame);
menuBtn.addEventListener("click", returnToMenu);
shareBtn.addEventListener("click", shareScore);
musicBtn.addEventListener("click", toggleMusic);
themeButtons.forEach((button) => {
  button.addEventListener("click", () => setTheme(button.dataset.theme));
});

resize();
resetGame();
setTheme(themeName);
requestAnimationFrame(loop);

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(() => {
      // Service worker registration is optional for local use.
    });
  });
}
